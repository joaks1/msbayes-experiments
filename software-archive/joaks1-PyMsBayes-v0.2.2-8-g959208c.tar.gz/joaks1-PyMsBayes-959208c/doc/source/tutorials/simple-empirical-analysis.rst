***************************
A Simple Empirical Analysis
***************************
