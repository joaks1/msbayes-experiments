###################
PyMsBayes Tutorials
###################

.. toctree::
    :maxdepth: 3

    background.rst
    simple-empirical-analysis.rst

