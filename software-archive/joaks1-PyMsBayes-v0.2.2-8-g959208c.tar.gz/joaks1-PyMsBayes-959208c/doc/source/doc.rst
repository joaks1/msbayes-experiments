.. PyMsBayes documentation master file, created by
   sphinx-quickstart on Sat May 17 16:35:13 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

#######################
PyMsBayes Documentation
#######################

Contents:

.. toctree::
    :maxdepth: 2
    :numbered:

    intro/intro
    intro/prerequisites
    intro/installation
    tutorials/index
    changes
    thanks/acknowledgments
    license/license-short
    zbib/references


Indices and tables
==================

* :ref:`search`

.. * :ref:`genindex`
.. * :ref:`modindex`
